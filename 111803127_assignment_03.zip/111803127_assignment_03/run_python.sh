pythonfile="convert.py"
csvfile="output.csv"
if [ -f $pythonfile ]
    then
        if [ ! -f $csvfile ]
            then
                python $pythonfile
            else
                echo "CSV File not found"
        fi
    else
        echo "Python file not found"
fi
